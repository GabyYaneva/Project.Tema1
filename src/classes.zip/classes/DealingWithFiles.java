package classes;
import interfaceve.cotrowFile;

import java.io.File;
import java.io.FileWriter;
import java.util.Scanner;

public class DealingWithFiles  implements cotrowFile {
    //chete fail
    //otwarq fail
    //da zaoiswa promeni

    String fileName="";
    File g=new File(fileName);
    Scanner scanf=new Scanner(System.in);
    @Override
    public void openFile() {
       
    }

    @Override
    public void closeFile() {
 scanf.close();
    }

    @Override
    public void saveFile() {
    }
    @Override
    public void saveAsFile() {

    }

    @Override
    public void help() {

    }



}
