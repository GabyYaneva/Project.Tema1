package interfaceve;

public interface cotrowFile {
    void openFile();
    void closeFile();
    void saveFile();
    void saveAsFile();
    void help();


}
